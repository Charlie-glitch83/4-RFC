# The Triad and Triad Kernel - Markdown Book Bundle

This bundle is a source-grounded explanation of the triad and triad kernel as they appear across the available source files.

It is intentionally written as a book rather than a short summary. The central object is the triad itself, not a project framework. The files are treated as evidence of how the triad reveals itself under many bodies: cosmology, kernel math, simulation, nucleosynthesis, observer structure, arithmetic/proof routing, failure memory, and recursion.

## Recommended reading order

1. `00_Source_Anchors.md` - the source map used while writing the book.
2. `01_The_Triad_At_Zero.md` - the root intuition and the cleanest definition.
3. `02_CIF.md`, `03_QV.md`, `04_RFL.md` - the three components.
4. `05_Memory_Return.md` - why `M_rec` is not a fourth component.
5. `06_Triad_Kernel.md` - First Action, recursive kernel, modal basis, weighted kernel, and projection kernel.
6. `07_Existence_Emergence.md` - how existence emerges from the triad in many forms.
7. `08_Manifestation_Atlas.md` - a catalog of manifestations across domains.
8. `09_Negative_Grammar.md` - what the triad is not.
9. `10_Scalar_Collapse.md` - why scalar flattening breaks the triad.
10. `11_Practical_Intuition.md` - how to think with the triad.
11. `12_Glossary.md` - compact reference.
12. `TRIAD_KERNEL_FULL_VOLUME.md` - all chapters combined.

## Core definition

The best current one-sentence definition is:

> The triad is the irreducible law by which admitted source-possibility is exposed to witnessed lawful crossing and becomes inheritable qualified memory.

Shorter:

> The triad is possibility becoming inheritable memory through witnessed crossing.

Shortest:

> admission -> exposure -> inheritance

Component form:

```text
CIF = admitted source-possibility
QV  = witnessed/exposed lawful crossing
RFL = inheritable qualified memory
```

Recurrence form:

```text
CIF -> QV -> RFL -> M_rec -> next CIF condition
```

`M_rec` is not a fourth component. It is the return path by which RFL memory conditions the next CIF without becoming the source-parent.
